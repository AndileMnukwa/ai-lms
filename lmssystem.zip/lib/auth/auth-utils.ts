// Authentication Utilities

import { sign, verify } from "jsonwebtoken"
import { hash, compare } from "bcrypt"
import { connectToDatabase } from "../mongodb/db"
import type { User } from "../mongodb/models"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"
const REFRESH_SECRET = process.env.REFRESH_SECRET || "your-refresh-secret"

// User registration
export async function registerUser(
  email: string,
  password: string,
  name: string,
): Promise<{ user: Omit<User, "password">; token: string }> {
  const { db } = await connectToDatabase()

  // Check if user already exists
  const existingUser = await db.collection("users").findOne({ email })
  if (existingUser) {
    throw new Error("User already exists")
  }

  // Hash password
  const hashedPassword = await hash(password, 10)

  // Create user object
  const user: User = {
    email,
    password: hashedPassword,
    name,
    role: "student",
    preferences: {
      learningStyle: "visual",
      pacePreference: "moderate",
      notificationSettings: {
        email: true,
        inApp: true,
      },
    },
    progress: {
      enrolledCourses: [],
      completedLessons: [],
      currentTimeline: 6, // Default to 6 months
      skillLevels: {},
    },
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  // Save user to database
  const result = await db.collection("users").insertOne(user)
  user._id = result.insertedId.toString()

  // Generate JWT token
  const token = generateToken(user)

  // Remove password from returned user object
  const { password: _, ...userWithoutPassword } = user

  return { user: userWithoutPassword, token }
}

// User login
export async function loginUser(
  email: string,
  password: string,
): Promise<{ user: Omit<User, "password">; token: string }> {
  const { db } = await connectToDatabase()

  // Find user
  const user = (await db.collection("users").findOne({ email })) as User
  if (!user) {
    throw new Error("User not found")
  }

  // Verify password
  const isPasswordValid = await compare(password, user.password)
  if (!isPasswordValid) {
    throw new Error("Invalid password")
  }

  // Generate JWT token
  const token = generateToken(user)

  // Remove password from returned user object
  const { password: _, ...userWithoutPassword } = user

  return { user: userWithoutPassword, token }
}

// Generate JWT token
function generateToken(user: User): string {
  return sign(
    {
      userId: user._id,
      email: user.email,
      role: user.role,
    },
    JWT_SECRET,
    { expiresIn: "1h" },
  )
}

// Generate refresh token
export function generateRefreshToken(userId: string): string {
  return sign({ userId }, REFRESH_SECRET, { expiresIn: "7d" })
}

// Verify JWT token
export function verifyToken(token: string): any {
  try {
    return verify(token, JWT_SECRET)
  } catch (error) {
    throw new Error("Invalid token")
  }
}

// Verify refresh token
export function verifyRefreshToken(token: string): any {
  try {
    return verify(token, REFRESH_SECRET)
  } catch (error) {
    throw new Error("Invalid refresh token")
  }
}

// Role-based access control middleware
export function checkRole(requiredRole: "student" | "instructor" | "admin") {
  return async (req: any, res: any, next: any) => {
    try {
      const token = req.headers.authorization?.split(" ")[1]
      if (!token) {
        return res.status(401).json({ message: "Authentication required" })
      }

      const decoded = verifyToken(token)
      if (decoded.role !== requiredRole && decoded.role !== "admin") {
        return res.status(403).json({ message: "Insufficient permissions" })
      }

      next()
    } catch (error) {
      return res.status(401).json({ message: "Invalid token" })
    }
  }
}
