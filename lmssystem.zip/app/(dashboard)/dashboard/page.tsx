"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/contexts/firebase-auth-context"
import { getCourses, getUserProgress } from "@/lib/firebase/firestore-utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import DashboardOverview from "@/components/dashboard/dashboard-overview"
import LearningPath from "@/components/dashboard/learning-path"
import AnalyticsDashboard from "@/components/dashboard/analytics-dashboard"
import UserProfile from "@/components/dashboard/user-profile"

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const [courses, setCourses] = useState([])
  const [progress, setProgress] = useState({})
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeTab, setActiveTab] = useState("overview")

  useEffect(() => {
    async function fetchData() {
      if (!user) return

      try {
        setIsLoading(true)
        // Fetch enrolled courses
        const enrolledCourseIds = user.progress?.enrolledCourses || []

        if (enrolledCourseIds.length > 0) {
          const coursesData = await Promise.all(
            enrolledCourseIds.map(async (courseId) => {
              try {
                // Fetch course data
                const course = await getCourses({ id: courseId })

                // Fetch progress for this course
                const progressData = await getUserProgress(user.uid, courseId)

                // Update progress state
                setProgress((prev) => ({
                  ...prev,
                  [courseId]: progressData,
                }))

                return course[0]
              } catch (err) {
                console.error(`Error fetching data for course ${courseId}:`, err)
                return null
              }
            }),
          )

          setCourses(coursesData.filter(Boolean))
        } else {
          // If user has no enrolled courses, fetch all available courses
          const allCourses = await getCourses()
          setCourses(allCourses.slice(0, 3)) // Show first 3 courses
        }
      } catch (err) {
        console.error("Error fetching dashboard data:", err)
        setError("Failed to load dashboard data. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    if (!loading) {
      fetchData()
    }
  }, [user, loading])

  if (loading || isLoading) {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
        <div className="space-y-6">
          <Skeleton className="h-[400px] w-full rounded-lg" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Skeleton className="h-[200px] w-full rounded-lg" />
            <Skeleton className="h-[200px] w-full rounded-lg" />
            <Skeleton className="h-[200px] w-full rounded-lg" />
          </div>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
        <Card>
          <CardContent className="p-6">
            <p className="mb-4">Please log in to view your dashboard.</p>
            <Button asChild>
              <Link href="/login">Go to Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
        <Card>
          <CardContent className="p-6">
            <p className="text-red-500 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()}>Retry</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4">
      <Tabs defaultValue="overview" className="w-full" onValueChange={setActiveTab}>
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-secondary">Learning Dashboard</h1>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="learning-path">Learning Path</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="overview">
          <DashboardOverview user={user} courses={courses} progress={progress} />
        </TabsContent>

        <TabsContent value="learning-path">
          <LearningPath />
        </TabsContent>

        <TabsContent value="analytics">
          <AnalyticsDashboard />
        </TabsContent>

        <TabsContent value="profile">
          <UserProfile />
        </TabsContent>
      </Tabs>
    </div>
  )
}
