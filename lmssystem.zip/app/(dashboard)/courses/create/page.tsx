"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/firebase-auth-context"
import { Loader2, BookOpen, Clock, Target, Users, GraduationCap } from "lucide-react"

export default function CreateCoursePage() {
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()
  const [isGenerating, setIsGenerating] = useState(false)
  const [formData, setFormData] = useState({
    topic: "",
    description: "",
    timelineMonths: "6",
    difficulty: "beginner",
    targetAudience: "",
    learningObjectives: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to create a course",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    if (!formData.topic) {
      toast({
        title: "Topic Required",
        description: "Please enter a topic for your course",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("/api/courses/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        const data = await response.json()
        if (data.success && data.course) {
          toast({
            title: "Course Created",
            description: "Your course has been generated successfully",
            variant: "default",
          })
          router.push(`/courses/${data.course.id}`)
        } else {
          toast({
            title: "Generation Failed",
            description: data.error || "Failed to generate course",
            variant: "destructive",
          })
        }
      } else {
        toast({
          title: "Generation Failed",
          description: "Failed to generate course",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error generating course:", error)
      toast({
        title: "Generation Failed",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-secondary mb-6">Create AI-Generated Course</h1>

        <Card>
          <CardHeader>
            <CardTitle>Course Details</CardTitle>
            <CardDescription>
              Provide information about the course you want to create. Our AI will generate a complete curriculum.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label htmlFor="topic" className="block text-sm font-medium text-secondary mb-1">
                    Course Topic <span className="text-red-500">*</span>
                  </label>
                  <div className="flex items-center">
                    <BookOpen className="h-5 w-5 text-text-light mr-2" />
                    <Input
                      id="topic"
                      name="topic"
                      value={formData.topic}
                      onChange={handleChange}
                      placeholder="e.g., JavaScript Programming, Machine Learning, Digital Marketing"
                      required
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-secondary mb-1">
                    Course Description
                  </label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Provide a brief description of what this course should cover"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="timelineMonths" className="block text-sm font-medium text-secondary mb-1">
                      Timeline (Months)
                    </label>
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-text-light mr-2" />
                      <Select
                        value={formData.timelineMonths}
                        onValueChange={(value) => handleSelectChange("timelineMonths", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select timeline" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 months</SelectItem>
                          <SelectItem value="6">6 months</SelectItem>
                          <SelectItem value="9">9 months</SelectItem>
                          <SelectItem value="12">12 months</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="difficulty" className="block text-sm font-medium text-secondary mb-1">
                      Difficulty Level
                    </label>
                    <div className="flex items-center">
                      <Target className="h-5 w-5 text-text-light mr-2" />
                      <Select
                        value={formData.difficulty}
                        onValueChange={(value) => handleSelectChange("difficulty", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select difficulty" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Intermediate</SelectItem>
                          <SelectItem value="advanced">Advanced</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="targetAudience" className="block text-sm font-medium text-secondary mb-1">
                    Target Audience
                  </label>
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-text-light mr-2" />
                    <Input
                      id="targetAudience"
                      name="targetAudience"
                      value={formData.targetAudience}
                      onChange={handleChange}
                      placeholder="e.g., Beginners with no prior knowledge, Professionals looking to upskill"
                      className="flex-1"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="learningObjectives" className="block text-sm font-medium text-secondary mb-1">
                    Learning Objectives
                  </label>
                  <div className="flex items-center">
                    <GraduationCap className="h-5 w-5 text-text-light mr-2 align-top mt-2" />
                    <Textarea
                      id="learningObjectives"
                      name="learningObjectives"
                      value={formData.learningObjectives}
                      onChange={handleChange}
                      placeholder="What should learners be able to do after completing this course?"
                      rows={3}
                      className="flex-1"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={isGenerating || !formData.topic}
                  className="bg-primary hover:bg-primary/90"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating Course...
                    </>
                  ) : (
                    "Generate Course"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
