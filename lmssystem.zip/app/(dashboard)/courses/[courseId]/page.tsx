"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { BookOpen, Users, Clock, Award, BarChart2, FileText, CheckCircle, Circle, AlertCircle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { enrollInCourse, isEnrolledInCourse } from "@/lib/firebase/course-utils"
import { useAuth } from "@/contexts/firebase-auth-context"

export default function CoursePage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()
  const courseId = params.courseId as string
  const [course, setCourse] = useState<any>(null)
  const [modules, setModules] = useState<any[]>([])
  const [progress, setProgress] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [enrolling, setEnrolling] = useState(false)
  const [isEnrolled, setIsEnrolled] = useState(false)

  useEffect(() => {
    fetchCourse()
    fetchModules()
    fetchProgress()
    checkEnrollmentStatus()
  }, [courseId, user])

  const fetchCourse = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`/api/courses/${courseId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setCourse(data.course)
      } else {
        console.error("Failed to fetch course")
      }
    } catch (error) {
      console.error("Error fetching course:", error)
    }
  }

  const fetchModules = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`/api/modules?courseId=${courseId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setModules(data.modules || [])
      } else {
        console.error("Failed to fetch modules")
      }
    } catch (error) {
      console.error("Error fetching modules:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchProgress = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`/api/progress?courseId=${courseId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setProgress(data.progress)
      } else {
        console.error("Failed to fetch progress")
      }
    } catch (error) {
      console.error("Error fetching progress:", error)
    }
  }

  const checkEnrollmentStatus = async () => {
    if (user) {
      const enrolled = await isEnrolledInCourse(courseId)
      setIsEnrolled(enrolled)
    }
  }

  const handleEnroll = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to enroll in this course",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    setEnrolling(true)
    try {
      const result = await enrollInCourse(courseId)

      if (result.success) {
        setIsEnrolled(true)
        toast({
          title: "Enrollment Successful",
          description: "You have successfully enrolled in this course",
          variant: "default",
        })
        // Refresh progress data
        fetchProgress()
      } else {
        toast({
          title: "Enrollment Failed",
          description: result.error || "Failed to enroll in course",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error enrolling in course:", error)
      toast({
        title: "Enrollment Failed",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setEnrolling(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!course) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-4rem)]">
        <BookOpen className="h-16 w-16 text-text-light mb-4" />
        <h2 className="text-2xl font-bold text-secondary mb-2">Course Not Found</h2>
        <p className="text-text-light mb-6">The course you're looking for doesn't exist or you don't have access.</p>
        <Button onClick={() => router.push("/courses")} className="bg-primary hover:bg-primary/90">
          Back to Courses
        </Button>
      </div>
    )
  }

  const completionPercentage = progress?.completionPercentage || 0
  const timelineMonths = course.timelineVariations?.[0]?.months || 6

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Course header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
          <div>
            <h1 className="text-3xl font-bold text-secondary mb-2">{course.title}</h1>
            <div className="flex flex-wrap gap-2 mb-4">
              {course.category?.map((cat, index) => (
                <span key={index} className="bg-secondary/10 text-secondary px-2 py-1 rounded text-sm">
                  {cat}
                </span>
              ))}
              <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm capitalize">
                {course.difficulty}
              </span>
              <span className="bg-accent/10 text-accent px-2 py-1 rounded text-sm">{timelineMonths} months</span>
            </div>
          </div>

          {!isEnrolled ? (
            <Button onClick={handleEnroll} disabled={enrolling} className="bg-primary hover:bg-primary/90 mt-4 md:mt-0">
              {enrolling ? "Enrolling..." : "Enroll in Course"}
            </Button>
          ) : (
            <div className="flex items-center bg-green-50 text-green-700 px-4 py-2 rounded-md mt-4 md:mt-0">
              <CheckCircle className="h-5 w-5 mr-2" />
              <span>Enrolled</span>
            </div>
          )}
        </div>

        <p className="text-text-light mb-6">{course.description}</p>

        {/* Progress bar - only show for enrolled users */}
        {isEnrolled && (
          <div className="bg-white p-4 rounded-lg border border-gray mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-secondary">Your Progress</span>
              <span className="font-medium text-secondary">{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2 mb-4" />
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center">
                <BookOpen className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm text-text-light">Lessons Completed</p>
                  <p className="font-medium text-secondary">
                    {progress?.completedLessons?.length || 0}/
                    {modules.reduce((acc, m) => acc + (m.lessons?.length || 0), 0)}
                  </p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-secondary mr-2" />
                <div>
                  <p className="text-sm text-text-light">Estimated Time</p>
                  <p className="font-medium text-secondary">
                    {modules.reduce((acc, m) => acc + (m.estimatedHours || 0), 0)} hours
                  </p>
                </div>
              </div>
              <div className="flex items-center">
                <Award className="h-5 w-5 text-accent mr-2" />
                <div>
                  <p className="text-sm text-text-light">Certificate</p>
                  <p className="font-medium text-secondary">
                    {completionPercentage === 100 ? "Available" : "Upon completion"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Not enrolled message */}
        {!isEnrolled && (
          <Card className="mb-6 bg-blue-50 border-blue-200">
            <CardContent className="p-4 flex items-center">
              <AlertCircle className="h-6 w-6 text-blue-600 mr-3" />
              <div>
                <p className="font-medium text-blue-800">Enroll to track your progress</p>
                <p className="text-sm text-blue-700">
                  Enroll in this course to track your progress and earn a certificate upon completion.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Course content */}
      <Tabs defaultValue="modules" className="space-y-6">
        <TabsList className="bg-white border border-gray">
          <TabsTrigger value="modules">
            <BookOpen className="h-4 w-4 mr-2" />
            Modules
          </TabsTrigger>
          <TabsTrigger value="overview">
            <BarChart2 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="resources">
            <FileText className="h-4 w-4 mr-2" />
            Resources
          </TabsTrigger>
          <TabsTrigger value="community">
            <Users className="h-4 w-4 mr-2" />
            Community
          </TabsTrigger>
        </TabsList>

        {/* Modules tab */}
        <TabsContent value="modules">
          <div className="space-y-6">
            {modules.map((module, moduleIndex) => (
              <Card key={module._id || moduleIndex}>
                <CardHeader className="pb-3">
                  <div className="flex items-center">
                    <div className="bg-secondary/10 text-secondary font-medium rounded-full w-8 h-8 flex items-center justify-center mr-3">
                      {moduleIndex + 1}
                    </div>
                    <div>
                      <CardTitle className="text-xl font-bold text-secondary">{module.title}</CardTitle>
                      <CardDescription className="text-text-light">
                        {module.estimatedHours} hours • {module.lessons?.length || 0} lessons
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-text-light mb-4">{module.description}</p>

                  <div className="space-y-3 mb-6">
                    {module.lessons?.map((lesson, lessonIndex) => {
                      const isCompleted = progress?.completedLessons?.includes(lesson.lessonId)
                      const isLocked = !isEnrolled && lessonIndex > 0

                      return (
                        <div key={lesson.lessonId || lessonIndex} className="flex items-center">
                          <div className="mr-3">
                            {isCompleted ? (
                              <div className="bg-green-100 rounded-full p-1">
                                <CheckCircle className="h-5 w-5 text-green-600" />
                              </div>
                            ) : (
                              <div className="bg-light-gray rounded-full p-1">
                                <Circle className="h-5 w-5 text-text-light" />
                              </div>
                            )}
                          </div>
                          <div className="flex-grow">
                            <p className="font-medium text-secondary">
                              {lessonIndex + 1}. {lesson.title || `Lesson ${lessonIndex + 1}`}
                            </p>
                            <p className="text-sm text-text-light">
                              {lesson.estimatedMinutes} min
                              {lesson.contentType === "video" && " • Video"}
                              {lesson.contentType === "interactive" && " • Interactive"}
                            </p>
                          </div>
                          <Button
                            variant={isCompleted ? "outline" : "default"}
                            size="sm"
                            disabled={isLocked}
                            className={
                              isLocked
                                ? "bg-gray-300 cursor-not-allowed"
                                : isCompleted
                                  ? "border-green-600 text-green-600 hover:bg-green-50"
                                  : "bg-primary hover:bg-primary/90"
                            }
                            onClick={() => {
                              if (!isLocked) {
                                router.push(`/courses/${courseId}/modules/${module._id}/lessons/${lesson.lessonId}`)
                              }
                            }}
                          >
                            {isLocked ? "Enroll to Access" : isCompleted ? "Review" : "Start"}
                          </Button>
                        </div>
                      )
                    })}
                  </div>

                  {module.assessmentId && (
                    <div className="border-t border-gray pt-4 mt-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Award className="h-5 w-5 text-accent mr-3" />
                          <div>
                            <p className="font-medium text-secondary">Module Assessment</p>
                            <p className="text-sm text-text-light">Test your knowledge of this module</p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={!isEnrolled}
                          className={
                            !isEnrolled
                              ? "bg-gray-300 cursor-not-allowed"
                              : "border-accent text-accent hover:bg-accent/10"
                          }
                          onClick={() => {
                            if (isEnrolled) {
                              router.push(`/courses/${courseId}/modules/${module._id}/assessment`)
                            }
                          }}
                        >
                          {isEnrolled ? "Take Assessment" : "Enroll to Access"}
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}

            {/* Certificate section */}
            <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center justify-between">
                  <div className="flex items-center mb-4 md:mb-0">
                    <Award className="h-12 w-12 text-primary mr-4" />
                    <div>
                      <h3 className="text-xl font-bold text-secondary mb-1">Course Certificate</h3>
                      <p className="text-text-light">Complete all modules and assessments to earn your certificate</p>
                    </div>
                  </div>
                  <Button
                    className={
                      !isEnrolled
                        ? "bg-gray-300 cursor-not-allowed"
                        : completionPercentage === 100
                          ? "bg-primary hover:bg-primary/90"
                          : "bg-gray-300"
                    }
                    disabled={!isEnrolled || completionPercentage !== 100}
                  >
                    {!isEnrolled
                      ? "Enroll to Unlock"
                      : completionPercentage === 100
                        ? "Get Certificate"
                        : "Complete Course to Unlock"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Other tabs remain the same */}
        <TabsContent value="overview">{/* Existing overview content */}</TabsContent>

        <TabsContent value="resources">{/* Existing resources content */}</TabsContent>

        <TabsContent value="community">{/* Existing community content */}</TabsContent>
      </Tabs>
    </div>
  )
}
