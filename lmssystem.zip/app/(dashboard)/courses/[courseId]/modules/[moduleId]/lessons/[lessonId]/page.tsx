"use client"

import { useParams } from "next/navigation"
import CourseSidebar from "@/components/courses/course-sidebar"
import LessonViewer from "@/components/lessons/lesson-viewer"

export default function LessonPage() {
  const params = useParams()
  const courseId = params.courseId as string
  const moduleId = params.moduleId as string
  const lessonId = params.lessonId as string

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sidebar */}
      <div className="hidden md:block w-64 h-full overflow-y-auto">
        <CourseSidebar courseId={courseId} />
      </div>

      {/* Main content */}
      <div className="flex-grow overflow-y-auto">
        <LessonViewer courseId={courseId} moduleId={moduleId} lessonId={lessonId} />
      </div>
    </div>
  )
}
