"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function JwtDebugger() {
  const [token, setToken] = useState<string | null>(null)
  const [decodedToken, setDecodedToken] = useState<any>(null)
  const [envVars, setEnvVars] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Get token from localStorage
    const storedToken = localStorage.getItem("adminToken")
    setToken(storedToken)

    if (storedToken) {
      try {
        // Decode token (without verification)
        const parts = storedToken.split(".")
        if (parts.length === 3) {
          const payload = JSON.parse(atob(parts[1]))
          setDecodedToken(payload)
        }
      } catch (err) {
        console.error("Error decoding token:", err)
      }
    }
  }, [])

  const checkEnvironment = async () => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/admin/debug-env")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to check environment")
      }

      setEnvVars(data)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const regenerateToken = async () => {
    setLoading(true)
    setError(null)

    try {
      // Get admin credentials from localStorage if available
      const adminUser = localStorage.getItem("adminUser")
      let email = ""

      if (adminUser) {
        try {
          const user = JSON.parse(adminUser)
          email = user.email
        } catch (e) {
          console.error("Error parsing admin user:", e)
        }
      }

      // Prompt for admin credentials
      const adminEmail = prompt("Enter admin email:", email) || ""
      const adminPassword = prompt("Enter admin password:") || ""

      const response = await fetch("/api/auth/admin-login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: adminEmail, password: adminPassword }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Login failed")
      }

      // Store new token
      localStorage.setItem("adminToken", data.token)
      localStorage.setItem("adminUser", JSON.stringify(data.user))

      setToken(data.token)

      // Decode new token
      const parts = data.token.split(".")
      if (parts.length === 3) {
        const payload = JSON.parse(atob(parts[1]))
        setDecodedToken(payload)
      }

      alert("Token regenerated successfully!")
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-light-gray p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-secondary">JWT Debugger</CardTitle>
            <CardDescription className="text-text-light">Diagnose JWT authentication issues</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-2">JWT Token Status:</h3>
              {token ? (
                <div className="p-3 bg-green-50 text-green-800 border border-green-200 rounded-md">
                  <p className="font-medium">Token found in localStorage</p>
                  <div className="mt-2">
                    <p className="text-sm font-medium">Token (first 20 chars):</p>
                    <p className="text-sm font-mono bg-white p-2 rounded mt-1 overflow-x-auto">
                      {token.substring(0, 20)}...
                    </p>
                  </div>
                </div>
              ) : (
                <Alert className="bg-red-50 text-red-800 border-red-200">
                  <AlertDescription>No token found in localStorage. Please log in first.</AlertDescription>
                </Alert>
              )}
            </div>

            {decodedToken && (
              <div>
                <h3 className="text-lg font-medium mb-2">Decoded Token Payload:</h3>
                <div className="bg-white p-4 rounded-md border overflow-x-auto">
                  <pre className="text-sm">{JSON.stringify(decodedToken, null, 2)}</pre>
                </div>
                <div className="mt-2 text-sm">
                  <p>
                    <span className="font-medium">Issued at:</span>{" "}
                    {decodedToken.iat ? new Date(decodedToken.iat * 1000).toLocaleString() : "N/A"}
                  </p>
                  <p>
                    <span className="font-medium">Expires at:</span>{" "}
                    {decodedToken.exp ? new Date(decodedToken.exp * 1000).toLocaleString() : "N/A"}
                  </p>
                  <p>
                    <span className="font-medium">Is expired:</span>{" "}
                    {decodedToken.exp && decodedToken.exp * 1000 < Date.now() ? "Yes" : "No"}
                  </p>
                </div>
              </div>
            )}

            {envVars && (
              <div>
                <h3 className="text-lg font-medium mb-2">Environment Variables:</h3>
                <div className="bg-white p-4 rounded-md border overflow-x-auto">
                  <pre className="text-sm">{JSON.stringify(envVars, null, 2)}</pre>
                </div>
              </div>
            )}

            {error && (
              <Alert className="bg-red-50 text-red-800 border-red-200">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row gap-3">
            <Button onClick={checkEnvironment} className="bg-secondary hover:bg-secondary/90" disabled={loading}>
              {loading ? "Checking..." : "Check Environment Variables"}
            </Button>
            <Button onClick={regenerateToken} className="bg-primary hover:bg-primary/90" disabled={loading}>
              {loading ? "Processing..." : "Regenerate Token"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
