"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle } from "lucide-react"

export default function TestJWT() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [token, setToken] = useState<string | null>(null)

  useEffect(() => {
    // Get token from localStorage
    const storedToken = localStorage.getItem("adminToken")
    setToken(storedToken)
  }, [])

  const testAuthentication = async () => {
    if (!token) {
      setError("No token found in localStorage. Please log in first.")
      return
    }

    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/admin/test-auth", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Authentication failed")
      }

      setResult(data)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-light-gray p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-secondary">JWT Authentication Test</CardTitle>
            <CardDescription className="text-text-light">
              Verify that your JWT authentication is working correctly
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-light-gray rounded-md">
              <h3 className="font-medium mb-2">JWT Token Status:</h3>
              {token ? (
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span>Token found in localStorage</span>
                </div>
              ) : (
                <div className="flex items-center text-red-600">
                  <XCircle className="h-5 w-5 mr-2" />
                  <span>No token found. Please log in first.</span>
                </div>
              )}
            </div>

            {error && (
              <Alert variant="destructive" className="bg-red-50 text-red-800 border-red-200">
                <XCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {result && (
              <div className="p-4 bg-green-50 text-green-800 border border-green-200 rounded-md">
                <div className="flex items-center mb-2">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span className="font-medium">{result.message}</span>
                </div>
                <div className="mt-2">
                  <h4 className="font-medium">Decoded Token Data:</h4>
                  <pre className="mt-2 p-3 bg-white rounded border text-sm overflow-auto">
                    {JSON.stringify(result.user, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button
              onClick={testAuthentication}
              className="bg-primary hover:bg-primary/90"
              disabled={loading || !token}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : (
                "Test JWT Authentication"
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
