"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, AlertCircle, BookOpen } from "lucide-react"
import { useRouter } from "next/navigation"

export default function SeedCoursePage() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const seedCourse = async () => {
    setLoading(true)
    setError(null)
    setSuccess(false)

    try {
      const token = localStorage.getItem("adminToken")
      if (!token) {
        throw new Error("You must be logged in as an admin to seed the database")
      }

      const response = await fetch("/api/admin/seed-course", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to seed course data")
      }

      setSuccess(true)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-light-gray p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-secondary">Seed Sample Course</CardTitle>
            <CardDescription className="text-text-light">
              Add a complete "Introduction to Web Development" course with modules, lessons, and assessments
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-light-gray p-6 rounded-lg border border-gray">
              <h3 className="text-lg font-bold text-secondary mb-4">Course Details</h3>
              <div className="space-y-4">
                <div>
                  <p className="font-medium text-secondary">Title</p>
                  <p className="text-text-light">Introduction to Web Development</p>
                </div>
                <div>
                  <p className="font-medium text-secondary">Modules</p>
                  <ul className="list-disc pl-5 text-text-light">
                    <li>HTML Fundamentals (6 lessons)</li>
                    <li>CSS Styling (6 lessons)</li>
                    <li>JavaScript Basics (6 lessons)</li>
                    <li>Responsive Web Design (6 lessons)</li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium text-secondary">Content Types</p>
                  <p className="text-text-light">Text lessons, video embeds, interactive exercises, and assessments</p>
                </div>
              </div>
            </div>

            {error && (
              <Alert variant="destructive" className="bg-red-50 text-red-800 border-red-200">
                <AlertCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 text-green-800 border-green-200">
                <CheckCircle className="h-4 w-4 mr-2" />
                <AlertDescription>
                  Course data seeded successfully! You can now view and manage the course in the admin dashboard.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => router.push("/admin/dashboard")}
              className="border-secondary text-secondary hover:bg-secondary/10"
            >
              Back to Dashboard
            </Button>
            <Button onClick={seedCourse} className="bg-primary hover:bg-primary/90" disabled={loading || success}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Seeding Course...
                </>
              ) : success ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Course Seeded
                </>
              ) : (
                <>
                  <BookOpen className="mr-2 h-4 w-4" />
                  Seed Sample Course
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
