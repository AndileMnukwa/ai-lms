"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  BarChart,
  BookOpen,
  Users,
  Award,
  FileText,
  Settings,
  PlusCircle,
  Trash2,
  Edit,
  Download,
  RefreshCw,
} from "lucide-react"
import { useRouter } from "next/navigation"

export default function AdminDashboard() {
  const [loading, setLoading] = useState(true)
  const [courses, setCourses] = useState([])
  const [stats, setStats] = useState({
    totalCourses: 0,
    totalStudents: 0,
    totalCertificates: 0,
    aiGeneratedCourses: 0,
  })
  const [dbStatus, setDbStatus] = useState({ connected: false, type: "Loading..." })
  const router = useRouter()

  useEffect(() => {
    // Check if admin is logged in
    const token = localStorage.getItem("adminToken")
    if (!token) {
      router.push("/admin")
      return
    }

    // Check database status
    checkDatabaseStatus()

    // Fetch courses and stats
    fetchCourses()
    fetchStats()
  }, [router])

  const checkDatabaseStatus = async () => {
    try {
      // For Firebase, we'll just check if we can connect
      setDbStatus({
        connected: true,
        type: "Firebase",
      })
    } catch (error) {
      console.error("Failed to check database status:", error)
      setDbStatus({
        connected: false,
        type: "Unknown (Error)",
      })
    }
  }

  const fetchCourses = async () => {
    setLoading(true)
    try {
      const token = localStorage.getItem("adminToken")

      const response = await fetch("/api/admin/courses", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (response.ok) {
        setCourses(data.courses || [])
      } else {
        console.error("Failed to fetch courses:", data.error)
      }
    } catch (error) {
      console.error("Failed to fetch courses:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem("adminToken")

      const response = await fetch("/api/admin/stats", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (response.ok) {
        setStats(data.stats)
      }
    } catch (error) {
      console.error("Failed to fetch stats:", error)
    }
  }

  const generateAICourse = async () => {
    try {
      const token = localStorage.getItem("adminToken")

      // Prompt for course topic
      const topic = prompt("Enter a topic for the AI-generated course:")
      if (!topic) return

      // Prompt for difficulty
      const difficulty = prompt("Enter difficulty level (beginner, intermediate, advanced):", "beginner")
      if (!difficulty) return

      // Prompt for timeline
      const timeline = prompt("Enter timeline in months (3, 6, 9, 12):", "6")
      if (!timeline) return

      const response = await fetch("/api/admin/generate-course", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          topic,
          difficulty,
          timelineMonths: Number.parseInt(timeline),
        }),
      })

      const data = await response.json()

      if (response.ok) {
        alert(`Course "${data.course.title}" generated successfully!`)
        fetchCourses()
        fetchStats()
      } else {
        alert(`Failed to generate course: ${data.error}`)
      }
    } catch (error) {
      console.error("Failed to generate AI course:", error)
      alert("Failed to generate AI course. See console for details.")
    }
  }

  const deleteCourse = async (courseId) => {
    if (!confirm("Are you sure you want to delete this course?")) return

    try {
      const token = localStorage.getItem("adminToken")

      const response = await fetch(`/api/admin/courses?id=${courseId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (response.ok) {
        alert("Course deleted successfully!")
        fetchCourses()
        fetchStats()
      } else {
        alert(`Failed to delete course: ${data.error}`)
      }
    } catch (error) {
      console.error("Failed to delete course:", error)
      alert("Failed to delete course. See console for details.")
    }
  }

  const editCourse = (courseId) => {
    router.push(`/admin/courses/edit/${courseId}`)
  }

  const viewCertificates = (courseId) => {
    router.push(`/admin/certificates?courseId=${courseId}`)
  }

  const handleLogout = () => {
    localStorage.removeItem("adminToken")
    localStorage.removeItem("adminUser")
    router.push("/admin")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-light">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-text-light">Loading admin dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-light-gray p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-secondary">Admin Dashboard</h1>
            <p className="text-text-light mt-1">Manage your AI-powered LMS platform</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 mt-4 md:mt-0">
            <Button onClick={generateAICourse} className="bg-accent hover:bg-accent/90 flex items-center">
              <PlusCircle className="mr-2 h-4 w-4" />
              Generate AI Course
            </Button>
            <Button
              onClick={() => router.push("/admin/generate-course")}
              className="bg-secondary hover:bg-secondary/90 flex items-center"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Advanced Course Generator
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
            >
              Logout
            </Button>
          </div>
        </div>

        {/* Database Status */}
        <Alert
          className={`mb-6 ${dbStatus.connected ? "bg-green-50 border-green-200" : "bg-amber-50 border-amber-200"}`}
        >
          <AlertDescription className="flex items-center">
            <div className={`w-3 h-3 rounded-full mr-2 ${dbStatus.connected ? "bg-green-500" : "bg-amber-500"}`}></div>
            <span>
              Database Status: <span className="font-medium">{dbStatus.type}</span>
              {!dbStatus.connected && <span className="ml-2 text-amber-700">(Database connection not available.)</span>}
            </span>
          </AlertDescription>
        </Alert>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-text-light">Total Courses</p>
                  <p className="text-2xl font-bold text-secondary">{stats.totalCourses}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-secondary/10 p-3 rounded-full mr-4">
                  <Users className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <p className="text-sm text-text-light">Total Students</p>
                  <p className="text-2xl font-bold text-secondary">{stats.totalStudents}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-accent/10 p-3 rounded-full mr-4">
                  <Award className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-text-light">Certificates Issued</p>
                  <p className="text-2xl font-bold text-secondary">{stats.totalCertificates}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <BarChart className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-text-light">AI-Generated Courses</p>
                  <p className="text-2xl font-bold text-secondary">{stats.aiGeneratedCourses}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="bg-white border border-gray">
            <TabsTrigger value="courses">
              <BookOpen className="h-4 w-4 mr-2" />
              Courses
            </TabsTrigger>
            <TabsTrigger value="certificates">
              <Award className="h-4 w-4 mr-2" />
              Certificates
            </TabsTrigger>
            <TabsTrigger value="reports">
              <FileText className="h-4 w-4 mr-2" />
              Reports
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Courses Tab */}
          <TabsContent value="courses">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-xl font-bold text-secondary">Course Management</CardTitle>
                    <CardDescription className="text-text-light">
                      Manage your courses and create new ones
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => router.push("/admin/courses/create")}
                      className="bg-primary hover:bg-primary/90"
                    >
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Add Course
                    </Button>
                    <Button onClick={fetchCourses} variant="outline" className="border-gray">
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {courses.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-text-light mb-4">No courses available.</p>
                    <Button onClick={generateAICourse} className="bg-accent hover:bg-accent/90">
                      Generate AI Course
                    </Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-light-gray border-b border-gray">
                          <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Title</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Category</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Difficulty</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Timeline</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Source</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-secondary">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {courses.map((course) => (
                          <tr key={course.id} className="border-b border-gray hover:bg-light-gray">
                            <td className="px-4 py-3 text-sm font-medium text-secondary">{course.title}</td>
                            <td className="px-4 py-3 text-sm text-text-light">{course.category?.join(", ")}</td>
                            <td className="px-4 py-3 text-sm text-text-light capitalize">{course.difficulty}</td>
                            <td className="px-4 py-3 text-sm text-text-light">
                              {course.timelineVariations?.[0]?.months || "-"} months
                            </td>
                            <td className="px-4 py-3 text-sm">
                              {course.isAIGenerated ? (
                                <span className="bg-accent/10 text-accent px-2 py-1 rounded text-xs">AI-Generated</span>
                              ) : (
                                <span className="bg-secondary/10 text-secondary px-2 py-1 rounded text-xs">Manual</span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-sm text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="h-8 border-secondary text-secondary hover:bg-secondary/10"
                                  onClick={() => editCourse(course.id)}
                                >
                                  <Edit className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="h-8 border-accent text-accent hover:bg-accent/10"
                                  onClick={() => viewCertificates(course.id)}
                                >
                                  <Award className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="h-8 border-red-500 text-red-500 hover:bg-red-50"
                                  onClick={() => deleteCourse(course.id)}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Certificates Tab */}
          <TabsContent value="certificates">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-secondary">Certificate Management</CardTitle>
                <CardDescription className="text-text-light">
                  View and manage certificates issued to students
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-text-light mb-4">View certificates issued to students upon course completion.</p>
                  <Button onClick={() => router.push("/admin/certificates")} className="bg-primary hover:bg-primary/90">
                    <Award className="mr-2 h-4 w-4" />
                    View All Certificates
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-secondary">Analytics & Reports</CardTitle>
                <CardDescription className="text-text-light">
                  View platform analytics and generate reports
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-text-light mb-4">
                    Access detailed analytics and generate reports on student progress and course performance.
                  </p>
                  <Button onClick={() => router.push("/admin/reports")} className="bg-primary hover:bg-primary/90">
                    <Download className="mr-2 h-4 w-4" />
                    Generate Reports
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-secondary">Platform Settings</CardTitle>
                <CardDescription className="text-text-light">Configure your LMS platform settings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-text-light mb-4">
                    Configure platform settings, including database connections, AI parameters, and user permissions.
                  </p>
                  <Button onClick={() => router.push("/admin/settings")} className="bg-primary hover:bg-primary/90">
                    <Settings className="mr-2 h-4 w-4" />
                    Manage Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
