"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Award, Download, Search, Eye, RefreshCw } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"

export default function CertificatesPage() {
  const [certificates, setCertificates] = useState([])
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [courseFilter, setCourseFilter] = useState("all")
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Check if admin is logged in
    const token = localStorage.getItem("adminToken")
    if (!token) {
      router.push("/admin")
      return
    }

    // Get courseId from query params if available
    const courseId = searchParams.get("courseId")
    if (courseId) {
      setCourseFilter(courseId)
    }

    // Fetch certificates and courses
    fetchCertificates()
    fetchCourses()
  }, [router, searchParams])

  const fetchCertificates = async () => {
    setLoading(true)
    try {
      const token = localStorage.getItem("adminToken")

      const response = await fetch("/api/admin/certificates", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (response.ok) {
        setCertificates(data.certificates || [])
      } else {
        console.error("Failed to fetch certificates:", data.error)
      }
    } catch (error) {
      console.error("Failed to fetch certificates:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCourses = async () => {
    try {
      const token = localStorage.getItem("adminToken")

      const response = await fetch("/api/admin/courses", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (response.ok) {
        setCourses(data.courses || [])
      }
    } catch (error) {
      console.error("Failed to fetch courses:", error)
    }
  }

  // Filter certificates based on search and course filter
  const filteredCertificates = certificates.filter((cert) => {
    const matchesSearch =
      cert.studentName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cert.courseName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cert.certificateId?.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCourse = courseFilter === "all" || cert.courseId === courseFilter

    return matchesSearch && matchesCourse
  })

  const handleViewCertificate = (certificateId) => {
    window.open(`/verify-certificate/${certificateId}`, "_blank")
  }

  const handleDownloadCertificate = (certificateId) => {
    // In a real implementation, this would download the certificate PDF
    alert(`Downloading certificate ${certificateId}`)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-light">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-text-light">Loading certificates...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-light-gray p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-secondary">Certificate Management</h1>
            <p className="text-text-light mt-1">View and manage certificates issued to students</p>
          </div>
          <Button
            onClick={() => router.push("/admin/dashboard")}
            variant="outline"
            className="mt-4 md:mt-0 border-secondary text-secondary hover:bg-secondary/10"
          >
            Back to Dashboard
          </Button>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-secondary">Search Certificates</CardTitle>
            <CardDescription className="text-text-light">
              Filter certificates by student name, course, or certificate ID
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-text-light" />
                <Input
                  type="search"
                  placeholder="Search certificates..."
                  className="pl-9 border-gray focus:border-primary"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="w-full md:w-64">
                <Select value={courseFilter} onValueChange={setCourseFilter}>
                  <SelectTrigger className="border-gray focus:border-primary">
                    <SelectValue placeholder="Filter by course" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Courses</SelectItem>
                    {courses.map((course) => (
                      <SelectItem key={course._id} value={course._id}>
                        {course.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={fetchCertificates} variant="outline" className="border-gray">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-bold text-secondary">Certificates</CardTitle>
            <CardDescription className="text-text-light">
              {filteredCertificates.length} certificates found
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredCertificates.length === 0 ? (
              <div className="text-center py-12">
                <Award className="h-12 w-12 text-gray mx-auto mb-4" />
                <p className="text-text-light mb-2">No certificates found</p>
                <p className="text-sm text-text-light">
                  {searchQuery || courseFilter !== "all"
                    ? "Try adjusting your search filters"
                    : "Certificates will appear here when students complete courses"}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-light-gray border-b border-gray">
                      <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Certificate ID</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Student</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Course</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-secondary">Issue Date</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-secondary">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCertificates.map((cert) => (
                      <tr key={cert.certificateId} className="border-b border-gray hover:bg-light-gray">
                        <td className="px-4 py-3 text-sm font-mono text-secondary">{cert.certificateId}</td>
                        <td className="px-4 py-3 text-sm text-text-light">{cert.studentName}</td>
                        <td className="px-4 py-3 text-sm text-text-light">{cert.courseName}</td>
                        <td className="px-4 py-3 text-sm text-text-light">
                          {new Date(cert.issuedDate).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3 text-sm text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 border-secondary text-secondary hover:bg-secondary/10"
                              onClick={() => handleViewCertificate(cert.certificateId)}
                            >
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 border-primary text-primary hover:bg-primary/10"
                              onClick={() => handleDownloadCertificate(cert.certificateId)}
                            >
                              <Download className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
