"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Award, CheckCircle, XCircle, Download } from "lucide-react"
import { useParams } from "next/navigation"

export default function VerifyCertificate() {
  const params = useParams()
  const [loading, setLoading] = useState(true)
  const [certificate, setCertificate] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (params.id) {
      verifyCertificate(params.id)
    }
  }, [params.id])

  const verifyCertificate = async (id) => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/certificates/verify/${id}`)
      const data = await response.json()

      if (response.ok) {
        setCertificate(data.certificate)
      } else {
        setError(data.error || "Failed to verify certificate")
      }
    } catch (err) {
      setError("An error occurred while verifying the certificate")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-light">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-text-light">Verifying certificate...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-light flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            {certificate ? (
              <div className="bg-green-100 p-4 rounded-full">
                <CheckCircle className="h-16 w-16 text-green-600" />
              </div>
            ) : (
              <div className="bg-red-100 p-4 rounded-full">
                <XCircle className="h-16 w-16 text-red-600" />
              </div>
            )}
          </div>
          <CardTitle className="text-2xl font-bold text-secondary">Certificate Verification</CardTitle>
          <CardDescription className="text-text-light">
            {certificate ? "This certificate has been verified as authentic." : "We could not verify this certificate."}
          </CardDescription>
        </CardHeader>

        {certificate ? (
          <CardContent className="space-y-6">
            <div className="bg-light-gray p-6 rounded-lg border border-gray">
              <div className="flex items-center justify-center mb-6">
                <Award className="h-12 w-12 text-primary mr-4" />
                <h2 className="text-xl font-bold text-secondary">Certificate of Completion</h2>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-text-light">Certificate ID</p>
                  <p className="font-medium text-secondary">{certificate.id}</p>
                </div>

                <div>
                  <p className="text-sm text-text-light">Student Name</p>
                  <p className="font-medium text-secondary">{certificate.studentName}</p>
                </div>

                <div>
                  <p className="text-sm text-text-light">Course</p>
                  <p className="font-medium text-secondary">{certificate.courseName}</p>
                </div>

                <div>
                  <p className="text-sm text-text-light">Issue Date</p>
                  <p className="font-medium text-secondary">
                    {new Date(certificate.issuedDate).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <p className="font-medium text-green-800">Verified Successfully</p>
                <p className="text-sm text-green-700 mt-1">
                  This certificate has been verified as authentic and was issued by EduAI LMS.
                </p>
              </div>
            </div>
          </CardContent>
        ) : (
          <CardContent>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
              <XCircle className="h-5 w-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <p className="font-medium text-red-800">Verification Failed</p>
                <p className="text-sm text-red-700 mt-1">
                  {error ||
                    "This certificate could not be verified. It may be invalid or may not exist in our records."}
                </p>
              </div>
            </div>
          </CardContent>
        )}

        <CardFooter className="flex justify-center">
          {certificate ? (
            <Button className="bg-primary hover:bg-primary/90">
              <Download className="mr-2 h-4 w-4" />
              Download Certificate
            </Button>
          ) : (
            <Button
              variant="outline"
              className="border-secondary text-secondary hover:bg-secondary/10"
              onClick={() => (window.location.href = "/")}
            >
              Return to Homepage
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
