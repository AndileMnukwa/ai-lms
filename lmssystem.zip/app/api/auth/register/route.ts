import { NextResponse } from "next/server"
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth"
import { auth } from "@/lib/firebase/firebase-config"
import { setDocument } from "@/lib/firebase/firestore-utils"

export async function POST(request: Request) {
  try {
    const { email, password, name } = await request.json()

    if (!email || !password || !name) {
      return NextResponse.json({ error: "Email, password, and name are required" }, { status: 400 })
    }

    console.log("Creating user with Firebase Auth...")
    // Create user in Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    console.log("Updating user profile...")
    // Update profile with name
    await updateProfile(user, { displayName: name })

    // Get ID token
    const token = await user.getIdToken()

    console.log("Creating user document in Firestore...")
    // Create user document in Firestore "users" collection
    const userData = {
      email,
      name,
      role: "student",
      preferences: {
        learningStyle: "visual",
        pacePreference: "moderate",
        notificationSettings: {
          email: true,
          inApp: true,
        },
      },
      progress: {
        enrolledCourses: [],
        completedLessons: [],
        currentTimeline: 6, // Default to 6 months
        skillLevels: {},
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // Store user data in the "users" collection
    await setDocument("users", user.uid, userData)
    console.log("User document created successfully!")

    // Return user data and token
    return NextResponse.json({
      user: {
        id: user.uid,
        email,
        name,
        role: "student",
      },
      token,
    })
  } catch (error: any) {
    console.error("Registration error:", error)

    // Handle Firebase auth errors
    if (error.code === "auth/email-already-in-use") {
      return NextResponse.json({ error: "Email already in use" }, { status: 400 })
    }

    return NextResponse.json({ error: error.message || "Registration failed" }, { status: 500 })
  }
}
