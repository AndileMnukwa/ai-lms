import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { sign } from "jsonwebtoken"
import { verifyIdToken, getUserById } from "@/lib/firebase/firebase-admin"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function POST(request: Request) {
  try {
    const { email, idToken } = await request.json()

    if (!email || !idToken) {
      return NextResponse.json({ error: "Email and idToken are required" }, { status: 400 })
    }

    // Verify the Firebase ID token
    const decodedToken = await verifyIdToken(idToken)
    const uid = decodedToken.uid

    // Get user data from Firebase
    const userRecord = await getUserById(uid)

    if (!userRecord) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Create a custom JWT token
    const token = sign(
      {
        userId: uid,
        email: userRecord.email,
        role: userRecord.customClaims?.role || "student",
      },
      JWT_SECRET,
      { expiresIn: "7d" },
    )

    // Set the token as an HTTP-only cookie
    cookies().set({
      name: "authToken",
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    })

    return NextResponse.json({
      success: true,
      user: {
        id: uid,
        email: userRecord.email,
        displayName: userRecord.displayName,
        role: userRecord.customClaims?.role || "student",
      },
      token,
    })
  } catch (error: any) {
    console.error("Login error:", error)
    return NextResponse.json({ error: error.message || "Authentication failed" }, { status: 401 })
  }
}
