import { NextResponse } from "next/server"
import { signInWithEmailAndPassword } from "firebase/auth"
import { auth } from "@/lib/firebase/firebase-config"
import { getDocumentById } from "@/lib/firebase/firestore-utils"
import type { User } from "@/lib/types/user"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password } = body

    // Get admin credentials from environment variables
    const ADMIN_EMAIL = process.env.ADMIN_EMAIL
    const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD

    console.log("Login attempt:", {
      email,
      providedPassword: password ? "✓" : "✗",
      expectedEmail: ADMIN_EMAIL,
      passwordMatch: password === ADMIN_PASSWORD,
    })

    // Check if credentials match environment variables
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      console.log("Admin login successful")

      try {
        // Try to sign in with Firebase
        const userCredential = await signInWithEmailAndPassword(auth, email, password)
        const firebaseUser = userCredential.user

        // Get ID token
        const token = await firebaseUser.getIdToken()

        // Get user data from Firestore
        const user = await getDocumentById<User>("users", firebaseUser.uid)

        if (user && user.role === "admin") {
          return NextResponse.json({
            user,
            token,
          })
        }
      } catch (firebaseError) {
        console.log("Firebase admin login failed, using fallback token")
      }

      // If Firebase login fails or user is not an admin, use fallback token
      return NextResponse.json({
        user: {
          id: "admin",
          email,
          name: "Administrator",
          role: "admin",
        },
        token: "admin-token", // This is a placeholder, in a real app you'd use a proper JWT
      })
    }

    console.log("Admin login failed: Invalid credentials")
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
  } catch (error: any) {
    console.error("Admin login error:", error)
    return NextResponse.json(
      {
        error: error.message || "Authentication failed",
        stack: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}
