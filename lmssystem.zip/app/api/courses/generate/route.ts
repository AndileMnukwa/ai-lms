import { NextResponse } from "next/server"
import { generateCourse } from "@/lib/ai/course-generator"
import { auth } from "@/lib/firebase/firebase-admin"

// Verify Firebase ID token
async function verifyToken(request: Request) {
  try {
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

    if (!token) {
      return { isAuthenticated: false, error: "Authentication required" }
    }

    const decodedToken = await auth.verifyIdToken(token)
    return { isAuthenticated: true, userId: decodedToken.uid }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAuthenticated: false, error: "Invalid token" }
  }
}

export async function POST(request: Request) {
  try {
    // Verify authentication
    const { isAuthenticated, userId, error } = await verifyToken(request)
    if (!isAuthenticated) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const { topic, timelineMonths, difficulty, description, targetAudience, learningObjectives } = await request.json()

    if (!topic || !timelineMonths || !difficulty) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Generate course with AI
    const course = await generateCourse(
      topic,
      Number(timelineMonths),
      difficulty as "beginner" | "intermediate" | "advanced",
      description,
      targetAudience,
      learningObjectives,
    )

    return NextResponse.json({
      success: true,
      course,
    })
  } catch (error: any) {
    console.error("Error generating course:", error)
    return NextResponse.json({ error: error.message || "Failed to generate course" }, { status: 500 })
  }
}
