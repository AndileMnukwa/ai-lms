import { NextResponse } from "next/server"
import { getAllDocuments, queryDocuments, addDocument, createWhereConstraint } from "@/lib/firebase/firestore-utils"
import type { Course } from "@/lib/types/user"
import { auth } from "@/lib/firebase/firebase-admin"

// Verify Firebase ID token
async function verifyToken(request: Request) {
  try {
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

    if (!token) {
      return { isAuthenticated: false, error: "Authentication required" }
    }

    const decodedToken = await auth.verifyIdToken(token)
    return { isAuthenticated: true, userId: decodedToken.uid }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAuthenticated: false, error: "Invalid token" }
  }
}

// Get all courses or filter by category
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const difficulty = searchParams.get("difficulty")

    let courses: Course[]

    if (category) {
      // Query courses by category
      courses = await queryDocuments<Course>("courses", [createWhereConstraint("category", "array-contains", category)])
    } else if (difficulty) {
      // Query courses by difficulty
      courses = await queryDocuments<Course>("courses", [createWhereConstraint("difficulty", "==", difficulty)])
    } else {
      // Get all courses
      courses = await getAllDocuments<Course>("courses")
    }

    return NextResponse.json({ courses })
  } catch (error: any) {
    console.error("Error fetching courses:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch courses" }, { status: 500 })
  }
}

// Create a new course
export async function POST(request: Request) {
  try {
    // Verify authentication
    const { isAuthenticated, userId, error } = await verifyToken(request)
    if (!isAuthenticated) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const courseData = await request.json()

    // Validate required fields
    if (!courseData.title || !courseData.description) {
      return NextResponse.json({ error: "Title and description are required" }, { status: 400 })
    }

    // Add creator and timestamps
    const course: Course = {
      ...courseData,
      creator: userId,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // Add course to Firestore
    const courseId = await addDocument("courses", course)

    return NextResponse.json({
      success: true,
      courseId,
      course: { ...course, id: courseId },
    })
  } catch (error: any) {
    console.error("Error creating course:", error)
    return NextResponse.json({ error: error.message || "Failed to create course" }, { status: 500 })
  }
}
