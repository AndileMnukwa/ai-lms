import { NextResponse } from "next/server"
import { verify } from "jsonwebtoken"
import { v4 as uuidv4 } from "uuid"
import { doc, getDoc, setDoc } from "firebase/firestore"
import { db } from "@/lib/firebase/firebase-config"
import { generateCertificate } from "@/lib/certificate/certificate-generator"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"
const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"

// Verify user token
async function verifyUserToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAuthenticated: false, error: "Authentication required" }
  }

  try {
    const decoded = verify(token, JWT_SECRET) as any
    return { isAuthenticated: true, userId: decoded.userId }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAuthenticated: false, error: "Invalid token" }
  }
}

// Store certificate in Firestore
async function storeCertificate(certificateData: any) {
  const certificateRef = doc(db, "certificates", certificateData.certificateId)
  await setDoc(certificateRef, {
    ...certificateData,
    issuedDate: new Date(),
    createdAt: new Date(),
    updatedAt: new Date(),
  })
}

export async function POST(request: Request) {
  try {
    // Verify user authentication
    const { isAuthenticated, userId, error } = await verifyUserToken(request)
    if (!isAuthenticated) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const { courseId, studentName } = await request.json()

    if (!courseId || !studentName) {
      return NextResponse.json({ error: "Course ID and student name are required" }, { status: 400 })
    }

    // Get course details from Firestore
    const courseRef = doc(db, "courses", courseId)
    const courseSnap = await getDoc(courseRef)

    if (!courseSnap.exists()) {
      return NextResponse.json({ error: "Course not found" }, { status: 404 })
    }

    const course = courseSnap.data()

    // Check if user has completed the course
    const progressRef = doc(db, "progress", `${userId}_${courseId}`)
    const progressSnap = await getDoc(progressRef)

    if (!progressSnap.exists() || progressSnap.data().completionPercentage !== 100) {
      return NextResponse.json({ error: "Course not completed" }, { status: 400 })
    }

    const progress = progressSnap.data()

    // Generate certificate ID
    const certificateId = uuidv4()

    // Create verification URL
    const verificationUrl = `${BASE_URL}/verify-certificate/${certificateId}`

    // Generate certificate PDF
    const pdfData = await generateCertificate({
      studentName,
      courseName: course.title,
      completionDate: progress.actualCompletionDate || new Date(),
      certificateId,
      verificationUrl,
    })

    // Store certificate in Firestore
    await storeCertificate({
      studentId: userId,
      courseId,
      certificateId,
      pdfUrl: pdfData,
      verificationUrl,
    })

    return NextResponse.json({
      success: true,
      certificateId,
      pdfUrl: pdfData,
      verificationUrl,
    })
  } catch (error: any) {
    console.error("Error generating certificate:", error)
    return NextResponse.json({ error: error.message || "Failed to generate certificate" }, { status: 500 })
  }
}
