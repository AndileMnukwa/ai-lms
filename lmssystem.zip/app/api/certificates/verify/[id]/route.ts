import { NextResponse } from "next/server"
import { doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase/firebase-config"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const certificateId = params.id

    if (!certificateId) {
      return NextResponse.json({ error: "Certificate ID is required" }, { status: 400 })
    }

    // Get certificate from Firestore
    const certificateRef = doc(db, "certificates", certificateId)
    const certificateSnap = await getDoc(certificateRef)

    if (!certificateSnap.exists()) {
      return NextResponse.json({ error: "Certificate not found" }, { status: 404 })
    }

    const certificate = certificateSnap.data()

    // Get student and course information
    const studentRef = doc(db, "users", certificate.studentId)
    const studentSnap = await getDoc(studentRef)

    const courseRef = doc(db, "courses", certificate.courseId)
    const courseSnap = await getDoc(courseRef)

    return NextResponse.json({
      valid: true,
      certificate: {
        id: certificateId,
        studentName: studentSnap.exists() ? studentSnap.data().name : "Student",
        courseName: courseSnap.exists() ? courseSnap.data().title : "Course",
        issuedDate: certificate.issuedDate,
      },
    })
  } catch (error: any) {
    console.error("Error verifying certificate:", error)
    return NextResponse.json({ error: error.message || "Failed to verify certificate" }, { status: 500 })
  }
}
