import { NextResponse } from "next/server"
import { addDocument, updateDocument } from "@/lib/firebase/firestore-utils"
import { sampleCourse } from "@/data/sample-course"

// Middleware to verify admin token (simplified for example)
async function verifyAdminToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAdmin: false, error: "Authentication required" }
  }

  // In a real app, you would verify the token with Firebase Admin SDK
  // For simplicity, we're just checking if it's the admin token
  if (token === "admin-token") {
    return { isAdmin: true }
  }

  return { isAdmin: false, error: "Admin access required" }
}

export async function POST(request: Request) {
  try {
    // Verify admin access
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    // Add course
    const courseId = await addDocument("courses", {
      ...sampleCourse.course,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    // Add modules
    const moduleIds = []
    for (const moduleData of sampleCourse.modules) {
      const moduleId = await addDocument("modules", {
        ...moduleData,
        courseId,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      moduleIds.push(moduleId)

      // Update module with lessons
      const lessonIds = []
      for (const lessonData of moduleData.lessons || []) {
        const lessonId = await addDocument("lessons", {
          ...lessonData,
          moduleId,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        lessonIds.push({
          lessonId,
          order: lessonData.order,
        })
      }

      // Update module with lesson IDs
      await updateDocument("modules", moduleId, { lessons: lessonIds })
    }

    // Update course with module IDs
    await updateDocument("courses", courseId, {
      timelineVariations: [
        {
          months: 6,
          modules: moduleIds,
        },
      ],
    })

    return NextResponse.json({
      success: true,
      message: "Sample course seeded successfully",
      courseId,
    })
  } catch (error: any) {
    console.error("Error seeding course:", error)
    return NextResponse.json({ error: error.message || "Failed to seed course" }, { status: 500 })
  }
}
