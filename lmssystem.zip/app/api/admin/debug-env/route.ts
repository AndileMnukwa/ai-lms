import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Check for environment variables (safely)
    const envInfo = {
      // Only return presence, not actual values for security
      hasJwtSecret: !!process.env.JWT_SECRET,
      jwtSecretLength: process.env.JWT_SECRET?.length || 0,
      jwtSecretPrefix: process.env.JWT_SECRET?.substring(0, 3) || "",

      hasRefreshSecret: !!process.env.REFRESH_SECRET,
      refreshSecretLength: process.env.REFRESH_SECRET?.length || 0,

      hasAdminEmail: !!process.env.ADMIN_EMAIL,
      adminEmailMasked: process.env.ADMIN_EMAIL
        ? process.env.ADMIN_EMAIL.substring(0, 3) +
          "..." +
          process.env.ADMIN_EMAIL.substring(process.env.ADMIN_EMAIL.indexOf("@"))
        : null,

      hasAdminPassword: !!process.env.ADMIN_PASSWORD,
      adminPasswordLength: process.env.ADMIN_PASSWORD?.length || 0,

      hasMongoUri: !!process.env.MONGODB_URI,
      mongoUriPrefix: process.env.MONGODB_URI
        ? process.env.MONGODB_URI.substring(0, process.env.MONGODB_URI.indexOf("://") + 3) + "..."
        : null,

      nodeEnv: process.env.NODE_ENV || "development",
    }

    return NextResponse.json(envInfo)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to check environment" }, { status: 500 })
  }
}
