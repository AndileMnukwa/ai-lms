import { NextResponse } from "next/server"
import { verify } from "jsonwebtoken"
import { ManagerAgent } from "@/lib/ai/agents"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware to verify admin token
async function verifyAdminToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAdmin: false, error: "Authentication required" }
  }

  try {
    const decoded = verify(token, JWT_SECRET) as any

    if (decoded.role !== "admin") {
      return { isAdmin: false, error: "Admin access required" }
    }
    return { isAdmin: true }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAdmin: false, error: "Invalid token" }
  }
}

export async function POST(request: Request) {
  try {
    // Verify admin access
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const { courseId, moduleTitle, moduleDescription, timelineMonths, order } = await request.json()

    if (!courseId || !moduleTitle) {
      return NextResponse.json({ error: "Course ID and module title are required" }, { status: 400 })
    }

    // Generate module with AI
    const managerAgent = new ManagerAgent()
    const module = await managerAgent.orchestrateJobQueue("generate_module", {
      courseId,
      moduleTitle,
      moduleDescription: moduleDescription || "",
      timelineMonths: timelineMonths || 3,
      order: order || 1,
    })

    return NextResponse.json({
      success: true,
      module,
    })
  } catch (error: any) {
    console.error("Error generating module:", error)
    return NextResponse.json({ error: error.message || "Failed to generate module" }, { status: 500 })
  }
}
