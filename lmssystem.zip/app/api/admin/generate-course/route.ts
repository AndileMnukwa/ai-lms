import { NextResponse } from "next/server"
import { verify } from "jsonwebtoken"
import { ManagerAgent } from "@/lib/ai/agents"
import { collection, addDoc, serverTimestamp } from "firebase/firestore"
import { db } from "@/lib/firebase/firebase-config"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware to verify admin token
async function verifyAdminToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAdmin: false, error: "Authentication required" }
  }

  try {
    const decoded = verify(token, JWT_SECRET) as any

    if (decoded.role !== "admin") {
      return { isAdmin: false, error: "Admin access required" }
    }
    return { isAdmin: true }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAdmin: false, error: "Invalid token" }
  }
}

export async function POST(request: Request) {
  try {
    // Verify admin access
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const { topic, description, difficulty, timelineMonths, targetAudience, learningObjectives } = await request.json()

    if (!topic || !difficulty || !timelineMonths) {
      return NextResponse.json({ error: "Topic, difficulty, and timelineMonths are required" }, { status: 400 })
    }

    // Generate course with AI
    const managerAgent = new ManagerAgent()
    const course = await managerAgent.orchestrateJobQueue("generate_curriculum", {
      topic,
      description,
      timelineMonths: Number.parseInt(timelineMonths),
      difficulty,
      targetAudience,
      learningObjectives,
    })

    // Log the course generation in Firestore
    await addDoc(collection(db, "admin_logs"), {
      action: "generate_course",
      courseId: course._id,
      courseTitle: course.title,
      timestamp: serverTimestamp(),
      parameters: {
        topic,
        difficulty,
        timelineMonths,
        targetAudience,
        learningObjectives,
      },
    })

    return NextResponse.json({
      success: true,
      course,
    })
  } catch (error: any) {
    console.error("Error generating course:", error)
    return NextResponse.json({ error: error.message || "Failed to generate course" }, { status: 500 })
  }
}
