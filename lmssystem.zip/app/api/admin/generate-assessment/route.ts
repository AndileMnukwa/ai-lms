import { NextResponse } from "next/server"
import { verify } from "jsonwebtoken"
import { ManagerAgent } from "@/lib/ai/agents"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware to verify admin token
async function verifyAdminToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAdmin: false, error: "Authentication required" }
  }

  try {
    const decoded = verify(token, JWT_SECRET) as any

    if (decoded.role !== "admin") {
      return { isAdmin: false, error: "Admin access required" }
    }
    return { isAdmin: true }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAdmin: false, error: "Invalid token" }
  }
}

export async function POST(request: Request) {
  try {
    // Verify admin access
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const { moduleId, topics, difficulty } = await request.json()

    if (!moduleId) {
      return NextResponse.json({ error: "Module ID is required" }, { status: 400 })
    }

    // Generate assessment with AI
    const managerAgent = new ManagerAgent()
    const assessment = await managerAgent.orchestrateJobQueue("generate_assessment", {
      moduleId,
      topics: topics || [],
      difficulty: difficulty || "intermediate",
    })

    return NextResponse.json({
      success: true,
      assessment,
    })
  } catch (error: any) {
    console.error("Error generating assessment:", error)
    return NextResponse.json({ error: error.message || "Failed to generate assessment" }, { status: 500 })
  }
}
