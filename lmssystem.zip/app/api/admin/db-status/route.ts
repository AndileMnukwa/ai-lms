import { NextResponse } from "next/server"
import { getFirestore } from "firebase-admin/firestore"
import { initializeFirebaseAdmin } from "@/lib/firebase/firebase-admin"

export async function GET() {
  try {
    // Initialize Firebase Admin
    initializeFirebaseAdmin()

    // Test connection to Firestore
    const db = getFirestore()
    const testDoc = await db.collection("_connection_test").doc("test").get()

    return NextResponse.json({
      connected: true,
      usingFirebase: true,
      message: "Connected to Firebase Firestore successfully",
    })
  } catch (error) {
    console.error("Firebase connection error:", error)

    return NextResponse.json(
      {
        connected: false,
        usingFirebase: false,
        message: "Failed to connect to Firebase Firestore",
        error: process.env.NODE_ENV === "development" ? error.message : "Connection error",
      },
      { status: 500 },
    )
  }
}
