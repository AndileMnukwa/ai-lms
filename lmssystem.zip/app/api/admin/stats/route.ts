import { NextResponse } from "next/server"
import { getAllDocuments, queryDocuments, createWhereConstraint } from "@/lib/firebase/firestore-utils"
import type { Course, User } from "@/lib/types/user"

// Middleware to verify admin token (simplified for example)
async function verifyAdminToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAdmin: false, error: "Authentication required" }
  }

  // In a real app, you would verify the token with Firebase Admin SDK
  // For simplicity, we're just checking if it's the admin token
  if (token === "admin-token") {
    return { isAdmin: true }
  }

  return { isAdmin: false, error: "Admin access required" }
}

export async function GET(request: Request) {
  try {
    // Verify admin access for security
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    // Get stats
    const totalCourses = await getAllDocuments<Course>("courses")
    const totalStudents = await queryDocuments<User>("users", [createWhereConstraint("role", "==", "student")])
    const totalCertificates = await getAllDocuments("certificates")

    // Count AI-generated courses
    const aiGeneratedCourses = totalCourses.filter((course) => course.isAIGenerated).length

    return NextResponse.json({
      stats: {
        totalCourses: totalCourses.length,
        totalStudents: totalStudents.length,
        totalCertificates: totalCertificates.length,
        aiGeneratedCourses,
      },
    })
  } catch (error: any) {
    console.error("Error fetching stats:", error)

    // Return fallback stats if database query fails
    return NextResponse.json({
      stats: {
        totalCourses: 3,
        totalStudents: 0,
        totalCertificates: 0,
        aiGeneratedCourses: 3,
      },
    })
  }
}
