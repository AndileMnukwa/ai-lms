import { NextResponse } from "next/server"
import { getAllDocuments, addDocument, deleteDocument } from "@/lib/firebase/firestore-utils"
import type { Course } from "@/lib/types/user"

// Middleware to verify admin token (simplified for example)
async function verifyAdminToken(request: Request) {
  const authHeader = request.headers.get("authorization")
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

  if (!token) {
    return { isAdmin: false, error: "Authentication required" }
  }

  // In a real app, you would verify the token with Firebase Admin SDK
  // For simplicity, we're just checking if it's the admin token
  if (token === "admin-token") {
    return { isAdmin: true }
  }

  return { isAdmin: false, error: "Admin access required" }
}

// Get all courses
export async function GET(request: Request) {
  try {
    // Verify admin access for security
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const courses = await getAllDocuments<Course>("courses")
    return NextResponse.json({ courses })
  } catch (error: any) {
    console.error("Error fetching courses:", error)
    return NextResponse.json({ error: error.message || "Failed to get courses" }, { status: 500 })
  }
}

// Create a new course
export async function POST(request: Request) {
  try {
    // Verify admin access
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const courseData = await request.json()

    // Add timestamps
    const course: Course = {
      ...courseData,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const courseId = await addDocument("courses", course)

    return NextResponse.json({
      success: true,
      courseId,
      course: { ...course, id: courseId },
    })
  } catch (error: any) {
    console.error("Error creating course:", error)
    return NextResponse.json({ error: error.message || "Failed to create course" }, { status: 500 })
  }
}

// Delete a course
export async function DELETE(request: Request) {
  try {
    // Verify admin access
    const { isAdmin, error } = await verifyAdminToken(request)
    if (!isAdmin) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const courseId = searchParams.get("id")

    if (!courseId) {
      return NextResponse.json({ error: "Course ID is required" }, { status: 400 })
    }

    await deleteDocument("courses", courseId)

    return NextResponse.json({
      success: true,
      message: "Course deleted successfully",
    })
  } catch (error: any) {
    console.error("Error deleting course:", error)
    return NextResponse.json({ error: error.message || "Failed to delete course" }, { status: 500 })
  }
}
