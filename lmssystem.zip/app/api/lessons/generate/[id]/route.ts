import { NextResponse } from "next/server"
import { generateLessonContent } from "@/lib/ai/course-generator"
import { auth } from "@/lib/firebase/firebase-admin"

// Verify Firebase ID token
async function verifyToken(request: Request) {
  try {
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : authHeader

    if (!token) {
      return { isAuthenticated: false, error: "Authentication required" }
    }

    const decodedToken = await auth.verifyIdToken(token)
    return { isAuthenticated: true, userId: decodedToken.uid }
  } catch (error) {
    console.error("Token verification error:", error)
    return { isAuthenticated: false, error: "Invalid token" }
  }
}

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    // Verify authentication
    const { isAuthenticated, error } = await verifyToken(request)
    if (!isAuthenticated) {
      return NextResponse.json({ error }, { status: 401 })
    }

    const lessonId = params.id
    if (!lessonId) {
      return NextResponse.json({ error: "Lesson ID is required" }, { status: 400 })
    }

    // Generate lesson content with AI
    const lesson = await generateLessonContent(lessonId)

    return NextResponse.json({
      success: true,
      lesson,
    })
  } catch (error: any) {
    console.error("Error generating lesson content:", error)
    return NextResponse.json({ error: error.message || "Failed to generate lesson content" }, { status: 500 })
  }
}
