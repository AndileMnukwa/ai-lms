import { NextResponse } from "next/server"
import { getDocumentById, updateDocument, createWhereConstraint, queryDocuments } from "@/lib/firebase/firestore-utils"
import { verifyIdToken } from "@/lib/firebase/firebase-admin"

// Get a lesson by ID
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    // Get lesson
    const lesson = await getDocumentById("lessons", params.id)
    if (!lesson) {
      return NextResponse.json({ error: "Lesson not found" }, { status: 404 })
    }

    return NextResponse.json({ lesson })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to get lesson" }, { status: 500 })
  }
}

// Update lesson progress
export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    // Verify authentication
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const decoded = await verifyIdToken(token)
    const userId = decoded.uid

    // Get lesson
    const lesson = await getDocumentById("lessons", params.id)
    if (!lesson) {
      return NextResponse.json({ error: "Lesson not found" }, { status: 404 })
    }

    // Get module to find courseId
    const module = await getDocumentById("modules", lesson.moduleId)
    if (!module) {
      return NextResponse.json({ error: "Module not found" }, { status: 404 })
    }

    const courseId = module.courseId

    // Get current progress
    const progressId = `${userId}_${courseId}`
    const progress = await getDocumentById("progress", progressId)

    // Update progress
    const completedLessons = progress?.completedLessons || []
    if (!completedLessons.includes(params.id)) {
      completedLessons.push(params.id)
    }

    // Create or update progress document
    await updateDocument(
      "progress",
      progressId,
      {
        userId,
        courseId,
        currentLesson: params.id,
        completedLessons,
        lastAccessDate: new Date(),
      },
      true,
    )

    // Calculate completion percentage
    const modules = await queryDocuments("modules", [createWhereConstraint("courseId", "==", courseId)])
    let totalLessons = 0

    for (const mod of modules) {
      totalLessons += mod.lessons?.length || 0
    }

    const completionPercentage = totalLessons > 0 ? Math.round((completedLessons.length / totalLessons) * 100) : 0

    await updateDocument("progress", progressId, { completionPercentage }, true)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to update progress" }, { status: 500 })
  }
}
