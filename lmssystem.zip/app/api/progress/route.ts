import { NextResponse } from "next/server"
import { getDocumentById, updateDocument } from "@/lib/firebase/firestore-utils"
import { verifyIdToken } from "@/lib/firebase/firebase-admin"

// Get progress for a course
export async function GET(request: Request) {
  try {
    // Verify authentication
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const decoded = await verifyIdToken(token)
    const userId = decoded.uid

    const { searchParams } = new URL(request.url)
    const courseId = searchParams.get("courseId")

    if (!courseId) {
      return NextResponse.json({ error: "Course ID is required" }, { status: 400 })
    }

    // Get progress
    const progressId = `${userId}_${courseId}`
    const progress = await getDocumentById("progress", progressId)

    if (!progress) {
      // Create initial progress document if it doesn't exist
      const initialProgress = {
        userId,
        courseId,
        completedLessons: [],
        startDate: new Date(),
        completionPercentage: 0,
        lastAccessDate: new Date(),
      }

      await updateDocument("progress", progressId, initialProgress, true)

      return NextResponse.json({ progress: initialProgress })
    }

    return NextResponse.json({ progress })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to get progress" }, { status: 500 })
  }
}
