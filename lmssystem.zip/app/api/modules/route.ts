import { NextResponse } from "next/server"
import { queryDocuments, getDocumentById, createWhereConstraint } from "@/lib/firebase/firestore-utils"

// Get modules for a course
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const courseId = searchParams.get("courseId")

    if (!courseId) {
      return NextResponse.json({ error: "Course ID is required" }, { status: 400 })
    }

    // Get modules for this course
    const modules = await queryDocuments("modules", [createWhereConstraint("courseId", "==", courseId)])

    // Sort modules by order
    modules.sort((a, b) => a.order - b.order)

    // Get lessons for each module
    for (const module of modules) {
      if (module.lessons && module.lessons.length > 0) {
        const lessonIds = module.lessons.map((l: any) => l.lessonId)
        const lessons = await Promise.all(lessonIds.map((id: string) => getDocumentById("lessons", id)))

        // Add lesson titles to module.lessons
        module.lessons = module.lessons.map((l: any) => {
          const lessonData = lessons.find((lesson: any) => lesson.id === l.lessonId)
          return {
            ...l,
            title: lessonData?.title || `Lesson ${l.order}`,
            contentType: lessonData?.contentType || "text",
          }
        })

        // Sort lessons by order
        module.lessons.sort((a: any, b: any) => a.order - b.order)
      }
    }

    return NextResponse.json({ modules })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to get modules" }, { status: 500 })
  }
}
