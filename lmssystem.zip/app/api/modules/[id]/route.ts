import { NextResponse } from "next/server"
import { getDocumentById } from "@/lib/firebase/firestore-utils"

// Get a module by ID
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    // Get module
    const module = await getDocumentById("modules", params.id)
    if (!module) {
      return NextResponse.json({ error: "Module not found" }, { status: 404 })
    }

    // Get lessons for this module
    if (module.lessons && module.lessons.length > 0) {
      const lessonIds = module.lessons.map((l: any) => l.lessonId)
      const lessons = await Promise.all(lessonIds.map((id: string) => getDocumentById("lessons", id)))

      // Add lesson titles to module.lessons
      module.lessons = module.lessons.map((l: any) => {
        const lessonData = lessons.find((lesson: any) => lesson.id === l.lessonId)
        return {
          ...l,
          title: lessonData?.title || `Lesson ${l.order}`,
          contentType: lessonData?.contentType || "text",
        }
      })

      // Sort lessons by order
      module.lessons.sort((a: any, b: any) => a.order - b.order)
    }

    return NextResponse.json({ module })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to get module" }, { status: 500 })
  }
}
