import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { FirebaseStatus } from "@/components/firebase-status"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-gray">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold">
              <span className="text-primary">EduAI</span>
              <span className="text-secondary">LMS</span>
            </h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/login">
              <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-primary hover:bg-primary/90">Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-light py-16 md:py-24 flex-grow">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold text-secondary leading-tight">
                AI-Powered Learning <span className="text-primary">Personalized</span> For You
              </h1>
              <p className="text-lg text-text-light">
                Our intelligent LMS platform dynamically generates personalized learning content based on your needs,
                with timeline-based structuring and AI-powered assessment capabilities.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/register">
                  <Button className="bg-primary hover:bg-primary/90 text-lg py-6 px-8">
                    Get Started
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/courses">
                  <Button
                    variant="outline"
                    className="border-secondary text-secondary hover:bg-secondary/10 text-lg py-6 px-8"
                  >
                    Explore Courses
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex justify-center">
              <img
                src="/placeholder.svg?height=400&width=500"
                alt="AI Learning Platform"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>

          {/* Firebase Status - only in development */}
          {process.env.NODE_ENV !== "production" && (
            <div className="mt-12 max-w-md mx-auto">
              <FirebaseStatus />
            </div>
          )}
        </div>
      </section>

      {/* Rest of the page content remains the same */}
      {/* ... */}
    </div>
  )
}
