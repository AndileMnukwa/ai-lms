import { LoginForm } from "@/components/auth/login-form"

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-light p-4">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold">
          <span className="text-primary">EduAI</span>
          <span className="text-secondary">LMS</span>
        </h1>
        <p className="text-text-light mt-2">AI-Powered Learning Management System</p>
      </div>
      <LoginForm />
    </div>
  )
}
